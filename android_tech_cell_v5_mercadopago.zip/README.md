# Android Tech Cell V4 — Mercado Pago

Base Next.js + PostgreSQL + Prisma com painel administrativo, clientes, créditos, pedidos e PIX integrado ao Mercado Pago.

## Local
1. Node.js 20+ e Docker Desktop.
2. Copie `.env.example` para `.env`.
3. Preencha `JWT_SECRET`, `ADMIN_PASSWORD` e, para PIX real, `MERCADOPAGO_ACCESS_TOKEN`, `MERCADOPAGO_WEBHOOK_SECRET` e `APP_URL`.
4. `docker compose up -d`
5. `npm install`
6. `npx prisma generate`
7. `npm run db:push`
8. `npm run seed`
9. `npm run dev`

## Mercado Pago
A criação do Pix usa a API de pagamentos do Mercado Pago no servidor. O token privado nunca deve ir para o navegador. O pagamento é criado com idempotência e `external_reference` ligado ao pagamento interno.

Em produção, configure no Mercado Pago um Webhook de pagamentos apontando para:
`https://SEU-DOMINIO.COM/api/payments/pix/webhook`

O webhook valida `x-signature`, consulta o pagamento no Mercado Pago e só então marca como pago e credita o usuário, evitando liberar créditos apenas porque alguém chamou a URL.

Use primeiro as credenciais de teste. Depois de validar todo o fluxo, troque para as credenciais produtivas.

## Produção
Use HTTPS, banco gerenciado com backup, segredos fora do repositório, rate limiting, logs e monitoramento. Não coloque Access Token no código ou frontend.

As integrações de serviços devem ser apenas APIs autorizadas; esta base não implementa bypass de FRP, contas ou mecanismos de segurança.
